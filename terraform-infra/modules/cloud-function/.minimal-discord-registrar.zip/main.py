def handler(request):
    """Minimal entry point - will be replaced by gcloud CLI deployment."""
    return {"message": "Function deployed via Terraform, update via gcloud CLI"}, 200

